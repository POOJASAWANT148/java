package com.lnt.mvc.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.model.EmployeeDetails;

public class EmployeeDetailDaoImp implements EmployeeDetailDao {
	private static final Logger logger = 			
			LoggerFactory.getLogger(EmployeeDetailDaoImp.class);
	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeDetails> getAllEmployeeList() {
		Session session = this.sessionFactory.getCurrentSession();
		List<EmployeeDetails> employeeList = session.createQuery("from EmployeeDetails").list();
		for (EmployeeDetails p : employeeList) {
			logger.info("EmployeeDetails List::" + p);
		}
		return employeeList;
		
	}

	@Override
	public EmployeeDetails getAllEmployeeDetails(int employeeDetailsId)
	{
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeDetails p = (EmployeeDetails) session.load(EmployeeDetails.class, new Integer(employeeDetailsId));
		logger.info("EmployeeDetails loaded successfully, EmployeeDetails=" + p);
		return p;
	}


	@Override
	public void createEmployeeDetails(EmployeeDetails employeeDetails) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(employeeDetails);
		logger.info("EmployeeDetails saved successfully, EmployeeDetails="
		+ employeeDetails);	
		
	}

	@Override
	public void deleteEmployeeDetails(int employeeDetailsId) {
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeDetails EmployeeDetails = 
		(EmployeeDetails) session.load(EmployeeDetails.class, new Integer(employeeDetailsId));
		if (null != EmployeeDetails) {
			session.delete(EmployeeDetails);
		}else {
			logger.error
			("Employee Details not deleted, with employeeDetails=" +employeeDetailsId);
		}
		logger.info("Employee Details deleted successfully, person details=" + EmployeeDetails);
	}
		
	

	@Override
	public void updateEmployeeDetails(EmployeeDetails employeeDetails) {
		Session session = this.sessionFactory
				.getCurrentSession();
		session.update(employeeDetails);
		logger.info("EmployeeDetalils update, "
				+ "successfully" +" "+ employeeDetails);
		
	}

	@Override
	public List<EmployeeDetails> getByNameEmp(String name) {

		String hql = "from EmployeeDetails e where e.firstname like : names";
		

		Session session = this.sessionFactory.getCurrentSession();
		Query query = (Query) session.createQuery(hql);
		
		List<EmployeeDetails> employeeList =((Query) query).list();
		
		return employeeList;
	
	}

}
