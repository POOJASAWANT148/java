package com.lnt.mvc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.mvc.model.Department;
import com.lnt.mvc.model.EmployeeDetails;

public class DepartmentDaoImpl implements DepartmentDao {
	private static final Logger logger = 	LoggerFactory.getLogger(EmployeeDetailDaoImp.class);
private SessionFactory sessionFactory;

@Autowired
public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
}
@Override
public void createDepartment(Department departmentDetails)
{	
	Session session = this.sessionFactory.getCurrentSession();
	session.persist(departmentDetails);
	logger.info("EmployeeDetails saved successfully, EmployeeDetails="
	+ departmentDetails);	
	
}
@Override
public void updateDepartment(Department departmentDetails) {
	Session session = this.sessionFactory
			.getCurrentSession();
	session.update(departmentDetails);
	logger.info("departmentDetails update, "
			+ "successfully" +" "+ departmentDetails);
}
@Override
public void deteleDepartment(int id) {
	Session session = this.sessionFactory.getCurrentSession();
	Department department = 
	(Department) session.load(Department.class, new Integer(id));
	if (null != department) {
		session.delete(department);
	}else {
		logger.error
		("Employee Details not deleted, with employeeDetails=" +id);
	}
	logger.info("Employee Details deleted successfully, person details=" + department);
	
}
@Override
public List<Department> getDepartment() {

	String hql = "from EmployeeDetails e where e.firstname like : names";
	

	Session session = this.sessionFactory.getCurrentSession();
	Query query = (Query) session.createQuery(hql);
	
	List<EmployeeDetails> employeeList =((Query) query).list();
	
	return employeeList;
	
}
@Override
public Department getAllDepartmentbyID(int Id) {

	return null;
}

}
