package com.lnt.mvc.dao;

import java.util.List;


import com.lnt.mvc.model.EmployeeDetails;

public interface EmployeeDetailDao {
public  void createEmployeeDetails(EmployeeDetails employeeDetails);
public  void updateEmployeeDetails(EmployeeDetails employeeDetails);
public  void deleteEmployeeDetails(int employeeDetailsId);
public List<EmployeeDetails> getAllEmployeeList();
public  EmployeeDetails getAllEmployeeDetails(int employeeDetailsId);
public List<EmployeeDetails> getByNameEmp(String name);

}
