package com.lnt.mvc.dao;

import java.util.List;
import java.util.Set;

import com.lnt.mvc.model.Department;


public interface DepartmentDao {
	
		public  void createDepartment(Department departmentDetails);
		public  void updateDepartment(Department departmentDetails);
		public  void deteleDepartment(int id);
		public List<Department> getDepartment();
		public  Department getAllDepartmentbyID(int Id);
		

}