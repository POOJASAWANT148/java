package com.lnt.mvc.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private int department_id;
	@Column
	private String departmentName;
	@OneToMany(cascade=CascadeType.ALL)
	private Set<EmployeeDetails> employee;
	
	
	
}
