package com.lnt.mvc.controller;

public class DepartmentController {

}
