package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.model.EmployeeDetails;



public interface EmployeeServiceDAO {
	public void createEmployeeDetails(EmployeeDetails e);
	public void updateEmployeeDetails(EmployeeDetails e);
	public void deleteEmployeeDetails(int id);
	public List<EmployeeDetails> listEmployeeDetails();
	public EmployeeDetails getEmployeeDetailsById(int id);
	public List<EmployeeDetails> getByNameEmp(String name);
	
	
	
}
