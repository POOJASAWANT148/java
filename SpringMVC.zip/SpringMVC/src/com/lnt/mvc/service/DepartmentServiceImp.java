package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.dao.DepartmentDao;
import com.lnt.mvc.model.Department;

public class DepartmentServiceImp implements DepartmentService {
private DepartmentDao depDao;

@Override
public void addDepartment(Department d) {
	this.depDao.createDepartment(d);
	
}

@Override
public void updateDepartment(Department e) {
this.depDao.updateDepartment(e);
}

@Override
public List<Department> listDepartment() {

	return this.depDao.getDepartment();
}

@Override
public Department getDepartmentById(int id) {
	// TODO Auto-generated method stub
	return this.depDao.getAllDepartmentbyID(id);
}

@Override
public void deleteDepartment(int id) {
this.depDao.deteleDepartment(id);
	
}
}
