package com.lnt.mvc.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.lnt.mvc.dao.EmployeeDetailDao;
import com.lnt.mvc.dao.EmployeeDetailDaoImp;
import com.lnt.mvc.model.EmployeeDetails;

public class EmployeeServiceImpl implements EmployeeServiceDAO {
private EmployeeDetailDao emp;
	@Override
	public void createEmployeeDetails(EmployeeDetails e) {
		this.emp.createEmployeeDetails(e);
		
	}
	@Override
	public void updateEmployeeDetails(EmployeeDetails e) {
		this.emp.updateEmployeeDetails(e);
		
	}
	@Override
	public void deleteEmployeeDetails(int id) {
		this.emp.deleteEmployeeDetails(id);
		
	}
	@Override
	public List<EmployeeDetails> listEmployeeDetails() {

		return this.emp.getAllEmployeeList();
	}
	@Override
	public EmployeeDetails getEmployeeDetailsById(int id) {
		return this.emp.getAllEmployeeDetails(id);
	}
	@Override
	public List<EmployeeDetails> getByNameEmp(String name) {
		return this.emp.getAllEmployeeList();
	}


}
