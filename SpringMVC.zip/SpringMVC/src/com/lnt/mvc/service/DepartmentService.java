package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.model.Department;



public interface DepartmentService {
	public void addDepartment(Department d);
	public void updateDepartment(Department e);
	public List<Department> listDepartment();
	public Department getDepartmentById(int id);
	public void deleteDepartment(int id);
}
